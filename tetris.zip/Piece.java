/**
 *
 * @author 
 * Reggie Barnett
 * Michael Moore
 * David Nard
 * Graham Taylor
 * Last Updated 4/19/2015, NetBeans IDE 8.0.2
 * CMSC 495
 * Phase 1 Source
 * 
 * Week 5
 * Spring OL1 2014
 */

package tetris;

import java.awt.Color;
import java.util.Random;

public class Piece 
{
    public enum gamePieces { emptyPiece, JPiece, LPiece, ZPiece, SPiece, TPiece, OPiece, IPiece };
    
    public static final int pieceMaxWidth = 4;

    protected int[][][] matrixArray;
    
    private gamePieces shape;
    private Color color;
   
    public Piece() 
    {        
        setPiece(gamePieces.emptyPiece, Square.colors[0]);        
    }

    public void setPiece(gamePieces newShape, Color newColor) 
    {
        // Set initial x,y for each Square
        // (10 / 2) - (4 / 2) = 3
        int leftX = (PlayField.playFieldWidth / 2) - (pieceMaxWidth / 2);
                
        // Every piece holds the data to be converted to any other piece. 
        //    The 1st dimension of the array matches the enum gamePieces ordinal value
        matrixArray = new int[][][] 
        {
            { { 0, 0 },   { 0, 0 },   { 0, 0 },   { 0, 0 } },
            { { leftX, PlayField.playFieldHeight - 2 },  { leftX + 1, PlayField.playFieldHeight - 2 },   { leftX + 2, PlayField.playFieldHeight - 2 },  { leftX, PlayField.playFieldHeight - 1 } },
            { { leftX, PlayField.playFieldHeight - 2 },  { leftX + 1, PlayField.playFieldHeight - 2 },   { leftX + 2, PlayField.playFieldHeight - 2 },  { leftX + 2, PlayField.playFieldHeight - 1 } },
            { { leftX, PlayField.playFieldHeight - 1 },  { leftX + 1, PlayField.playFieldHeight - 1 },   { leftX + 1, PlayField.playFieldHeight - 2 },  { leftX + 2, PlayField.playFieldHeight - 2 } },
            { { leftX, PlayField.playFieldHeight - 2 },  { leftX + 1, PlayField.playFieldHeight - 2 },   { leftX + 1, PlayField.playFieldHeight - 1 },  { leftX + 2, PlayField.playFieldHeight - 1 } },            
            { { leftX, PlayField.playFieldHeight - 2 },  { leftX + 1, PlayField.playFieldHeight - 2 },   { leftX + 2, PlayField.playFieldHeight - 2 },  { leftX + 1, PlayField.playFieldHeight - 1 } },
            { { leftX + 1, PlayField.playFieldHeight - 2 },  { leftX + 2, PlayField.playFieldHeight - 2 },   { leftX + 1, PlayField.playFieldHeight - 1 },  { leftX + 2, PlayField.playFieldHeight - 1 } },
            { { leftX, PlayField.playFieldHeight - 2 },  { leftX + 1, PlayField.playFieldHeight - 2 },   { leftX + 2, PlayField.playFieldHeight - 2 },  { leftX + 3, PlayField.playFieldHeight - 2 } }
        };

        shape = newShape;
        color = newColor;
    }
    
    public gamePieces getPiece()
    {
        return shape;
    }
    
    public void createPiece()
    {
        // Generate a new random piece with correct color
        Random randomInt = new Random();
        int randomPiece = Math.abs(randomInt.nextInt()) % 7 + 1;
        gamePieces[] pieceArray = gamePieces.values(); 
        setPiece(pieceArray[randomPiece], Square.colors[randomPiece]);
    }    
    
    public void setColor(Color newColor)
    {
        color = newColor;
    }
    
    public Color getColor()
    {
        return color;
    }
}